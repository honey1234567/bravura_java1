import mypack.palindrome1;
import mypack.reverse1;
import mypack.prime1;
class A
{

public static void main(String[] args)
  {

    palindrome1 obj=new palindrome1();
    reverse1 obj2=new reverse1();
    obj2.reverse(201);
    prime1 obj3=new prime1();
    obj3.primeno(7);
    obj.palindrome(13231);
    
  }

}
