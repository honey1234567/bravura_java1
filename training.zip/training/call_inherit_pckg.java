import inheritance.palindrome_inherit;
class call_inherit_pckg
{
  public static void main(String args[])
   {
     palindrome_inherit o=new palindrome_inherit ();
     o.palindrome(501);
     o.reverse(210);
     o.primeno(7);
 }
}
