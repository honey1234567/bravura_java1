import vehicle.twowheeler.HONDA.yamaha_model;

import vehicle.fourwheeler.Mercedes.mercedes;
class vehicle_tree
{

public static void main(String args[])
  {
    yamaha_model yum=new yamaha_model(1050,"yamaha");
    mercedes mer=new mercedes(20150,"mercedes");
  }

}