package vehicle.fourwheeler.Mercedes;
public class mercedes
{ int  speed;
  String name;
   public mercedes(int speed,String name)
    {
      this.speed=speed;
      this.name=name;
      System.out.println("speed is"+this.speed);
      System.out.println("name is"+this.name);
     }
}