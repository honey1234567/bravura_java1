package vehicle.twowheeler.Honda;
public class yamaha_model
{
  int speed;
  String name;
  public yamaha_model(int speed,String name)
    {
       this.speed=speed;
        this.name=name;
 System.out.println("speed is"+this.speed);
      System.out.println("name is"+this.name);
    }
}